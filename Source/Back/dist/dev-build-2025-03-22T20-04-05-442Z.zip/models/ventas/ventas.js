
const { DataTypes, TINYINT } = require('sequelize');
const { dbConnection } = require('../../database/config');

const Ventas = dbConnection.define('ventas', {
    idventas:{
        type:DataTypes.INTEGER,
        unique:true,
        primaryKey: true,
        autoIncrement:true
    },
    createDate:{
        type:DataTypes.DATE
    },
    idUser:{
        type: DataTypes.INTEGER,
        references: 'usuarios',
        referencesKey: 'idUser'
    },
    efectivo: {
        type: DataTypes.DECIMAL(18, 2)
    },
    tarjeta: {
        type: DataTypes.DECIMAL(18, 2)
    },
    transferencia: {
        type: DataTypes.DECIMAL(18, 2)
    },
    subtotal: {
        type: DataTypes.DECIMAL(18, 2)
    },
    descuento: {
        type: DataTypes.DECIMAL(18, 2)   
    },
    iva:{
        type:DataTypes.DECIMAL(10,2)
    },
    total:{
        type:DataTypes.DECIMAL(18,2)
    },
    idCliente:{
        type: DataTypes.INTEGER,
        references: 'clientes',
        referencesKey: 'idCliente'
    },
    idSucursal:{
        type: DataTypes.INTEGER,
        references: 'sucursales',
        referencesKey: 'idSucursal'
    },
    active:{
        type: DataTypes.BOOLEAN
    }    
},{    
createdAt: false,
updatedAt: false
});

module.exports= Ventas;

