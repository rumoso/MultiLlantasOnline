
const { DataTypes, TINYINT } = require('sequelize');
const { dbConnection } = require('../../database/config');
const CartDetail = require('./cartdetail');

const Cart = dbConnection.define('cart', {
    idcart:{
        type:DataTypes.INTEGER,
        unique:true,
        primaryKey: true,
        autoIncrement:true
    },
    createDate:{
        type:DataTypes.DATE
    },
    idUser:{
        type: DataTypes.INTEGER,
        references: 'usuarios',
        referencesKey: 'idUser'
    },
    idCliente:{
        type: DataTypes.INTEGER,
        references: 'clientes',
        referencesKey: 'idCliente'
    },
    idSucursal:{
        type: DataTypes.TINYINT,
        references: 'sucursales',
        referencesKey: 'idSucursal'
    }
},{    
createdAt: false,
updatedAt: false,
tableName: 'cart'
});

const setupAssociations = () => {
    Cart.hasMany(CartDetail, {
        foreignKey: 'idcart',
        sourceKey: 'idcart',
        as: 'productos'
    });

    CartDetail.belongsTo(Cart, {
        foreignKey: 'idcart',
        targetKey: 'idcart'
    });
};

module.exports= {Cart, setupAssociations};

