
const { DataTypes, TINYINT } = require('sequelize');
const { dbConnection } = require('../../database/config');

const VentasDetalle = dbConnection.define('ventasdetalle', {

    idventasdetalle:{
        type:DataTypes.INTEGER,
        unique:true,
        primaryKey: true,
        autoIncrement:true
    },
    idventas:{
        type: DataTypes.INTEGER,
        references: 'ventas',
        referencesKey: 'idventas'
    },
    sku:{
        type:DataTypes.STRING
    },
    idProducto:{
        type: DataTypes.INTEGER,
        references: 'productos',
        referencesKey: 'idProducto'
    },
    descripcion:{
        type:DataTypes.STRING
    },    
    cantidad:{
        type:DataTypes.DECIMAL(10,2)    
    },
    precio:{
        type:DataTypes.DECIMAL(18,2)
    }
},{    
createdAt: false,
updatedAt: false
});

module.exports= Ventas;

