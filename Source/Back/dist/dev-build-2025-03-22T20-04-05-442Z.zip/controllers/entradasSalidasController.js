const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const cbxCatMovEntradaSalida = async(req, res = response) => {

    const { search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxCatMovEntradaSalida( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const insertUpdateEntradaSalida = async (req, res) => {
    const {
        idEntradasSalidasH
        , idCatMov
        , active
        , idUserLogON
    } = req.body;

    try {

        if(!idCatMov > 0){
            return res.json({
                status: 1,
                message: 'Debes seleccionar motivo'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateEntradaSalida( 
            '${ oGetDateNow }'
            , ${ idEntradasSalidasH }
            , ${ idCatMov }
            , ${ active }
            , ${ idUserLogON }
            )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getEntradasSalidasPaginado = async (req, res) => {
    const { search = '', limiter = 10, start = 0, idUserLogON } = req.body;

    try {
        const result = await dbConnection.query(`CALL getEntradasSalidasPaginado('${search}', ${start}, ${limiter}, ${idUserLogON})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getEntradaSalidaByID = async (req, res) => {
    const { idEntradasSalidasH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getEntradaSalidaByID( ${idEntradasSalidasH} )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxArticulosParaES = async(req, res = response) => {

    const { idEntradasSalidasH, idCatMov, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxArticulosParaES( ${ idEntradasSalidasH }, ${ idCatMov }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const agregarEntradaSalidaDetalle = async (req, res) => {
    const { idEntradasSalidasH, idProducto, cantidad, idCatMov } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');
        
        if(!(idEntradasSalidasH > 0 && idProducto > 0 && cantidad > 0 && idCatMov > 0 )){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oProducto = await dbConnection.query(`CALL getProductoByID( ${idProducto} )`);

        if(oProducto.length == 0 ){
            return res.json({
                status: 1,
                message: 'No se encontró el producto'
            });
        }

        if(idCatMov == 2 && oProducto[0].idCatTipoProducto == 3){

            const inventario = await dbConnection.query(`CALL consultarInvParaFormulaDeProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
            console.log(inventario);
    
            if(inventario.length == 0){
                return res.json({
                    status: 2,
                    message: 'No hay inventario para generar esta fórmula'
                });
            }
    
    
            const requerimiento = await dbConnection.query(`CALL consultarFormulaNecesariaProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
            console.log(requerimiento);
    
            if(requerimiento.length > 0 && inventario.length > 0){
            
                let resultado = [];
    
                requerimiento.forEach((req) => {
                    let { idMateriaPrima, cantNecesaria, materiaPrimaName } = req;
                    let stockDisponible = inventario
                        .filter((item) => item.idMateriaPrima === idMateriaPrima)
                        .sort((a, b) => a.idStock - b.idStock); // FIFO: Más viejo primero
        
                    //console.log('cantNecesaria', cantNecesaria);
                    //console.log('stockDisponible', stockDisponible);
        
                    let cantidadRestante = cantNecesaria;
        
                    for (let stock of stockDisponible) {
        
                        if (cantidadRestante <= 0) break;
        
                        let cantidadATomar = Math.min(stock.cantidadDisp, cantidadRestante);
                        //console.log('cantidadATomar', cantidadATomar);
                        resultado.push({
                            bOK: cantidadATomar > 0,
                            idStock: stock.idStock,
                            createDate: stock.createDate,
                            idMateriaPrima,
                            materiaPrimaName,
                            cantidadDisp: stock.cantidadDisp,
                            cantidadConsumida: Number((cantidadATomar).toFixed(2)), // Redondeo a 2 decimales,
                            costoUnitario: stock.costo,
                            costoTotal: Number((stock.costo * cantidadATomar).toFixed(2)),
                            idOrdenDeCompra: ( stock.idOrdenDeCompra > 0 ? 'OC#' + stock.idOrdenDeCompra : '' )
                        });
        
                        cantidadRestante -= cantidadATomar;
                    }
        
                    if (cantidadRestante > 0) {
                        resultado.push({
                            bOK: false,
                            idStock: null, 
                            createDate: null,
                            idMateriaPrima,
                            materiaPrimaName,
                            cantidadDisp: 0,
                            cantidadConsumida: Number(cantidadRestante.toFixed(2)),
                            costoUnitario: 0,
                            costoTotal: 0,
                            idOrdenDeCompra: ''
                        });
                    }
                });
        
                console.log(resultado)
        
                let costoTotal = 0;
                let bOKGeneral = true;
        
                resultado.forEach(item => {
                    costoTotal += parseFloat(item.costoTotal);
                    if (item.bOK == false) {
                        bOKGeneral = false;
                    }
                });
    
                if(bOKGeneral && bProducir){
    
                    const jsonString = JSON.stringify(resultado, null, 2);
                    //console.log( 'jsonString', jsonString )
                    
                    const oSQL = await dbConnection.query(`CALL producirProdBase(
                        '${ oGetDateNow }'
                        , ${ idProductoBase }
                        , '${ cantAProducir }'
                        , '${ costoTotal }'
                        , '${ jsonString }'
                        )`);
                    console.log('oSQL', oSQL);
    
                    return res.json({
                        status: oSQL[0].out_id > 0 ? 0 : 1,
                        message: oSQL[0].message,
                        insertID: oSQL[0].out_id
                    });
    
                }
    
                return res.json({
                    status: 0,
                    message: 'Ejecutado correctamente.',
                    data: {
                        bOKGeneral: bOKGeneral,
                        costoTotal: costoTotal,
                        cantProducida: cantAProducir,
                        rows: resultado
                    }
                });
    
            }

        }


        



        const result = await dbConnection.query(`CALL agregarEntradaSalidaDetalle( ${ idEntradasSalidasH }, ${ idProducto }, '${ cantidad }')`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getEntradaSalidaDetallePaginado = async (req, res) => {
    const { idEntradasSalidasH = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getEntradaSalidaDetallePaginado( ${ idEntradasSalidasH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: result.length,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {
    
    cbxCatMovEntradaSalida
    , insertUpdateEntradaSalida
    , getEntradasSalidasPaginado
    , getEntradaSalidaByID
    , cbxArticulosParaES
    , agregarEntradaSalidaDetalle
    , getEntradaSalidaDetallePaginado

};


