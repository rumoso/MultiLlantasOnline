const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getProdProdFinalPaginado = async (req, res) => {
    const { startDate = '', endDate = '', search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdFinalPaginado(
            '${ startDate.substring(0, 10) }'
            , '${ endDate.substring(0, 10) }'
            , '${search}'
            , ${start}
            , ${limiter}
            )`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxProductosFinalForPF = async(req, res = response) => {

    const { search = '', idProdProdFinalH } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxProductosFinalForPF( '${ search }', ${ idProdProdFinalH } )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const agregarProdFinalDetalle = async (req, res) => {

    var { idProdProdFinalH = 0, idProductoFinal, cantAProducir, idUserLogON } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const inventario = await dbConnection.query(`CALL consultarInvDeProdAgranelProdFinal( ${ idProductoFinal } )`);
        console.log(inventario);

        if(inventario.length == 0){
            return res.json({
                status: 2,
                message: 'No hay inventario para generar'
            });
        }

        let resultadoProdAgranel = [];
        let resultadoInsumos = [];

        //console.log('cantNecesaria', cantNecesaria);
        //console.log('stockDisponible', stockDisponible);

        const oProducto = await dbConnection.query(`CALL getProductoByID( ${ idProductoFinal } )`);

        var valorMedida = oProducto[0].valorMedida;

        let cantidadRestante = cantAProducir * valorMedida;

        for (let stock of inventario) {

            if (cantidadRestante <= 0) break;

            let cantidadATomar = Math.min(stock.cantidadDisp, cantidadRestante);
            //console.log('cantidadATomar', cantidadATomar);
            resultadoProdAgranel.push({
                bOK: cantidadATomar > 0,
                idStock: stock.idStock,
                createDate: stock.createDate,
                idProductoFrom: stock.idProductoFrom,
                productoFromName: stock.productoFromName,
                cantidadDisp: stock.cantidadDisp,
                cantidadConsumida: Number((cantidadATomar).toFixed(2)), // Redondeo a 2 decimales,
                costoUnitario: stock.costo,
                costoTotal: Number((stock.costo * cantidadATomar).toFixed(2))
            });

            cantidadRestante -= cantidadATomar;
        }

        if (cantidadRestante > 0) {
            resultadoProdAgranel.push({
                bOK: false,
                idStock: null, 
                createDate: null,
                idProductoFrom: 0,
                productoFromName: '',
                cantidadDisp: 0,
                cantidadConsumida: Number(cantidadRestante.toFixed(2)),
                costoUnitario: 0,
                costoTotal: 0
            });
        }

        console.log('resultadoProdAgranel', resultadoProdAgranel)

        let costoTotal = 0;
        let bOKProdAgranel = resultadoProdAgranel.length > 0;
        let bOKInsumos = false;
        let bOKGeneral = true;

        resultadoProdAgranel.forEach(item => {
            costoTotal += parseFloat(item.costoTotal);
            if (item.bOK == false) {
                bOKProdAgranel = false;
            }
        });

        if(bOKProdAgranel){

            const inventarioInsumos = await dbConnection.query(`CALL consultarInvDeInsumosParaProdFinal( ${ idProductoFinal } )`);
            console.log(inventarioInsumos);

            if(inventarioInsumos.length == 0){
                return res.json({
                    status: 2,
                    message: 'No tiene configurado los insumos en el producto'
                });
            }

            bOKInsumos = inventarioInsumos.length > 0;

            for (let stock of inventarioInsumos) {

                resultadoInsumos.push({
                    bOK: stock.idStock > 0 && stock.cantidadDisp > 0,
                    idStock: stock.idStock,
                    createDate: stock.createDate,
                    idInsumo: stock.idInsumo,
                    insumoName: stock.insumoName,
                    cantidadDisp: stock.cantidadDisp,
                    cantidadConsumida: cantAProducir, // Redondeo a 2 decimales,
                    costoUnitario: stock.costo,
                    costoTotal: stock.costo * cantAProducir,
                    idOrdenDeCompra: stock.idRelacionOperacion
                });
    
            }

            console.log('resultadoInsumos', resultadoInsumos);

            resultadoInsumos.forEach(item => {
                costoTotal += parseFloat(item.costoTotal);
                if (item.bOK == false) {
                    bOKInsumos = false;
                }
            });

            console.log('bOKInsumos', bOKInsumos)

            if(bOKInsumos){

                if(idProdProdFinalH == 0 && bOKInsumos)
                {
                    var oInsertUpdate = await dbConnection.query(`CALL insertUpdateProdProdFinal(
                        '${ oGetDateNow }'
                        , ${ idProdProdFinalH }
                        , 1
                        , ${ idUserLogON })`);
    
                    if(oInsertUpdate.length == 0){
                        return res.json({
                            status: 2,
                            message: 'No se pudo generar ID para la producción'
                        });
                    }
                    else{
                        idProdProdFinalH = oInsertUpdate[0].out_id;
                        
                    }
                }
    
                var oAgregarPPFDetalle = await dbConnection.query(`CALL agregarProdProdFinalDetalle(
                '${ oGetDateNow }'
                , ${ idProdProdFinalH }
                , ${ idProductoFinal }
                , ${ cantAProducir }
                , ${ costoTotal / cantAProducir }
                , ${ costoTotal })`);
    
                console.log('oAgregarPPFDetalle', oAgregarPPFDetalle)
    
                if(oAgregarPPFDetalle.length == 0){
                    return res.json({
                        status: 2,
                        message: 'No se pudo agregar el producto a la lista'
                    });
                }
                else{
                    var idProdProdFinalDetalle = oAgregarPPFDetalle[0].out_id;
    
                    console.log( 'idProdProdFinalDetalle', idProdProdFinalDetalle )
    
                    const jsonString = JSON.stringify(resultadoProdAgranel, null, 2);
                    //console.log( 'jsonString', jsonString )
                    
                    const oSQL = await dbConnection.query(`CALL insertProdProdFinalStock(
                        ${ idProdProdFinalDetalle }
                        , '${ jsonString }'
                        )`);
    
                    console.log('oSQL', oSQL);
    
                    const JSONStringInsumos = JSON.stringify(resultadoInsumos, null, 2);
                    //console.log( 'jsonString', jsonString )
                    
                    const oSQLInsumos = await dbConnection.query(`CALL insertProdProdFinalInsumosStock(
                        ${ idProdProdFinalDetalle }
                        , '${ JSONStringInsumos }'
                        )`);
    
                    console.log('oSQL', oSQLInsumos);
                
                }
            }

        }

        bOKGeneral = bOKProdAgranel && bOKInsumos;

        return res.json({
            status: bOKGeneral ? 0 : 1,
            message: bOKGeneral ? 'Ejecutado correctamente.'
            : !bOKProdAgranel && bOKInsumos ? 'Hay problemas con el producto agranel'
            : bOKProdAgranel && !bOKInsumos ? 'Hay problemas con los insumos'
            : !bOKProdAgranel && !bOKInsumos ? 'Hay problemas con el producto agranel y con los insumos'
            : '',
            insertID: idProdProdFinalH,
            data: {
                bOKGeneral: bOKGeneral,
                bOKProdAgranel: bOKProdAgranel,
                bOKInsumos: bOKInsumos,
                costoTotal: costoTotal,
                cantProducida: cantAProducir,
                resultadoProdAgranel: resultadoProdAgranel,
                resultadoInsumos: resultadoInsumos
            }
        });

    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdFinalByID = async (req, res) => {
    const { idProdProdFinalH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdFinalByID( ${ idProdProdFinalH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdFinalDetalle = async (req, res) => {
    const { idProdProdFinalH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdFinalDetalle( ${ idProdProdFinalH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const completarYProducirPF = async (req, res) => {
    const { idProdProdFinalH, idUserLogON } = req.body;

    try {

        if(!(idProdProdFinalH > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL producirProdFinal( '${ oGetDateNow }', ${ idProdProdFinalH }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deletePPFDetail = async (req, res) => {
    const { idProdProdFinalH, idProdProdFinalDetalle, idUserLogON } = req.body;

    try {

        if(!(idProdProdFinalH > 0 && idProdProdFinalDetalle > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const result = await dbConnection.query(`CALL deletePPFDetail( ${ idProdProdFinalH }, ${ idProdProdFinalDetalle }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].iRows > 0 ? 0 : 1,
            message: "Eliminado correctamente"
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {

    getProdProdFinalPaginado
    , cbxProductosFinalForPF
    , agregarProdFinalDetalle
    , getProdProdFinalByID
    , getProdProdFinalDetalle
    , completarYProducirPF
    , deletePPFDetail
};
