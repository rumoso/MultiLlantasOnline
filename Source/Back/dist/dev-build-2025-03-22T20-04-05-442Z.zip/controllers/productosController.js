const { response } = require('express');
const { Op } = require('sequelize');
const { dbConnection } = require('../database/config');
const moment = require('moment');

const UnidadMedida = require('../models/productos/unidadmedida');
const Familias = require('../models/productos/familias');
const Productos = require('../models/productos/productos');
const Descripciones = require('../models/productos/descripciones');
const CatTipoProducto = require('../models/productos/cattipoproducto');

const unidadesMedidaGet = async(req, res = response) => {
    const {search="", start= 0, limiter = 100} = req.body;
    const { count, rows} = await UnidadMedida.findAndCountAll({ 
                    where:{[Op.or]:[{name:{[Op.like]:'%'+search+'%'}},{abreviatura:{[Op.like]:'%'+search+'%'}}]},
                    limit:parseInt(limiter),
                    offset:parseInt(start)    
                });
    
    res.json({
        status:0,
        message:'Unidades de medida',
        data:{count, rows}
    });
}

const unidadesMedidaGuardar = async(req, res = response) => {
    const { idUnidadMedida = 0, name, abreviatura, active} = req.body;
  
    try{

        if( idUnidadMedida === 0){
            UnidadMedida.create({idUnidadMedida, name, abreviatura, active}).then(
                unidadMedida =>{
                        res.json({
                            status:0,
                            message: 'Unidad medida Guardada.',
                            data:unidadMedida
                        });
                }
            ).catch(error => console.error(error));
        }else{
            const unidadMedida = await UnidadMedida.update({name, abreviatura, active}, { where: { idUnidadMedida } } );

            res.json({
                status:0,
                message: 'Unidad de medida Actualizada.',
                data:unidadMedida
            });
        }

    }catch(error){
        res.json({
            status:2,
            message: 'Ocurrió un error en el servicio.',
            data: error
        });
    }    
}

const unidadMedidaById = async(req, res = response) =>{
    const idUnidadMedida = req.params.id;
    const unidadesmedida = await UnidadMedida.findByPk(idUnidadMedida);
    
    res.json({
        status:0,
        message:'Unidades de medida por Id.',
        data:unidadesmedida
    });
}

const unidadMedidaDelete = async(req, res = response) => {
    const idUnidadMedida = req.params.id;
    const unidadesmedida = await UnidadMedida.destroy({where:{idUnidadMedida}});
    
    res.json({
        status:0,
        message:'Unidad de medida eliminada.',
        data:unidadesmedida
    });
}


const familiasGet = async(req, res = response) => {

    const {search="", start= 0, limiter = 100} = req.body;
    const { count, rows} = await Familias.findAndCountAll({ 
                    where:{name:{[Op.like]:'%'+search+'%'}, active:true},
                    limit:limiter,
                    offset:start    
                });
    
    res.json({
        status:0,
        message:'Consulta de Familias',
        data:{count, rows}
    });        
}

const familiaById = async(req, res = response) =>{
    const idFamilia = req.params.id;
    const familia = await Familias.findByPk(idFamilia);
    
    res.json({
        status:0,
        message:'Familia por Id.',
        data:familia
    });
}

const familiaDelete = async(req, res = response) => {
    const idFamilia = req.params.id;
    // const familia = await Familias.destroy({where:{idFamilia}});
    const familia = await Familias.update( {active:false}, { where: { idFamilia} }  );
    
    res.json({
        status:0,
        message:'familia eliminada.',
        data:familia
    });
}

const familiasGuardar = async(req, res = response) => {
    const { idFamilia = 0, name, active} = req.body;
    
    try{

        if( idFamilia === 0){
            Familias.create({idFamilia, name, active}).then(
                familia =>{
                        res.json({
                            status:0,
                            message: 'Familia Guardada.',
                            data:familia
                        });
                }
            ).catch(error => console.error(error));
        }else{

            const familia = await Familias.update({ name, active }, { where: { idFamilia } } );
            res.json({
                status:0,
                message: 'Familia actualizada.',
                data:familia
            });
        }

    }catch(error){
        res.json({
            status:2,
            message: 'Ocurrió un error en el servicio.',
            data: error
        });
    }    
}

const productoIDSugerido = async(req, res) => {
    const producto = await Productos.findOne( {  order: [ ['idProducto', 'DESC']], attributes:['idProducto'] });
    let folioSugerido = producto ? (producto.idproducto + 1) : 1;
    res.json({
        status:0,
        message:'',
        data:(folioSugerido)
    });
}


const productosGetAll = async(req, res = response) => {
        
    const{ limiter = 1000, start = 0, search = "", tipoProducto = 0} =req.body;
    
    let where = {active: 1};

    if( tipoProducto > 0 ){
        where = { ...where, idCatTipoProducto:tipoProducto};
    }
    
    
    const {count, rows }= await Productos.findAndCountAll( 
        { where, 
        order: [
            ['idProducto', 'ASC']
        ],
        include:[ 
            {
                model: Descripciones,                 
                as:'descripciones',
                required:true,
                where: {description:{[Op.like]: '%'+search+'%'}}
            },
            {
                model: CatTipoProducto,                 
                as:'tipoproducto',
                required:true
            },
            {
                model:UnidadMedida,
                as:'unidadmedida',
                required:true
            },
            {
                model:Productos,
                as:'productobase',
                required:false,
                include:[{
                    model: Descripciones,                 
                    as:'descripciones',
                    required:true,
                }]
            }
        ] ,
        offset: parseInt(start),
        limit: parseInt(limiter)
        });            

res.json({
    status:0,
    message:'',
    data:{
        count,
        rows
    }
});
}

const productoGuardar = async(req, res = response) => {
    const { idProducto = 0, createDate, sku, idDescription, valorMedida, idUnidadMedida, idCatTipoProducto = 1,
            idProductoRelacion=0, costo, precio, precioConEnvase, precioMayorista, precioMayoristaConEnvase,active} = req.body;

    try{

        if( idProducto === 0){
            Productos.create({idProducto, createDate, sku, idDescription, valorMedida, idUnidadMedida, idCatTipoProducto, 
                    idProductoRelacion, costo, precio, precioConEnvase, precioMayorista, precioMayoristaConEnvase, active}).then(
                producto =>{
                    // Sucursal.findAll().then(sucursal => {   
                    //     sucursal.forEach(suc =>{ 
                    //         let sucursalID = suc.idSucursal;
                    //         let cantidad = 0;
                    //         let ultima_actualizacion = Date.now();
                    //         let idSucursal = sucursalID;
                    //         let idproducto = producto.idproducto;
                            
                    //         Stock.create({cantidad, ultima_actualizacion, idSucursal, idproducto});
                    //     });
                    //     })
                    //     .catch(error => console.error(error));
                        
                        res.json({
                            status:0,
                            message: 'Producto Guardado.',
                            data:producto
                        });
                }
            ).catch(error => console.error(error));
        }else{
            const producto = await Productos.update({createDate, sku, idDescription, valorMedida, idUnidadMedida, idCatTipoProducto, 
                                                    idProductoRelacion,  costo, precio, precioConEnvase, precioMayorista, 
                                                    precioMayoristaConEnvase,active}, { where: { idProducto } } );

            res.json({
                status:0,
                message: 'Producto Actualizado.',
                data:producto
            });
        }

    }catch(error){
        res.json({
            status:2,
            message: 'Ocurrió un error en el servicio.',
            data: error
        });
    }
    
}

const productosGetById = async(req, res = response) => {        
    const idProducto = req.params.id;
    const{ idsucursal=0 } =req.query;
    const producto = await Productos.findOne( { 
        where: { active: 1, idProducto }, 
        include:[ 
            {
                model: Descripciones,                 
                as:'descripciones',
                required:true
            },
            {
                model: CatTipoProducto,                 
                as:'tipoproducto',
                required:true
            },
            {
                model:UnidadMedida,
                as:'unidadmedida',
                required:true
            },
            {
                model:Productos,
                as:'productobase',
                required:false,
                include:[{
                    model: Descripciones,                 
                    as:'descripciones',
                    required:true,
                },
                {
                    model:UnidadMedida,
                    as:'unidadmedida',
                    required:true
                }]
            }] 
    });            

    res.json({
        status:0,
        message:'',
        data:producto
    });
}

const productosDelete = async(req, res) => {
    const idProducto = req.params.id;
    
    const producto = await Productos.update( {active:false}, { where: { idProducto} }  );

    res.json({
        status:0,
        message:'Producto eliminado.',
        data:producto
    });
}

const obtenerDescripciones = async(req, res) =>{
    const{ search = "", start, limiter =1000 } =req.body;
    
    const {count, rows } = await Descripciones.findAndCountAll( 
        { where: { description:{[Op.like]:'%' + search + '%'}, active:true},
        offset: parseInt(start),
        limit: parseInt(limiter)    }  );

    res.json({
        status:0,
        message:'Obtener descripciones.',
        data:{count, rows }
    });
}

const getCatTipoProductoAll = async( req, res ) => {
    const{ search = "", start=0, limiter =1000 } =req.body;
    
    const {count, rows } = await CatTipoProducto.findAndCountAll( { where: { descripcion:{[Op.like]:'%' + search + '%'}},
        offset: parseInt(start),
        limit: parseInt(limiter)    }  );

    res.json({
        status:0,
        message:'Obtener catálogo tipo de productos.',
        data:{count, rows }
    });
}

const descripcionGuardar= async(req, res = response) => {
    const { idDescription = 0, description, active} = req.body;
    
    try{

        if( idDescription === 0){
            Descripciones.create({idDescription, description, active}).then(
                descripcion =>{
                        res.json({
                            status:0,
                            message: 'Descripción Guardada.',
                            data:descripcion
                        });
                }
            ).catch(error => console.error(error));
        }else{

            const descripcion = await Descripciones.update({ description, active }, { where: { idDescription } } );
            res.json({
                status:0,
                message: 'Descripción actualizada.',
                data:descripcion
            });
        }

    }catch(error){
        res.json({
            status:2,
            message: 'Ocurrió un error en el servicio.',
            data: error
        });
    }    
}

const descripcionById = async(req, res = response) =>{
    const idDescription = req.params.id;
    const descripcion = await Descripciones.findByPk(idDescription);
    
    res.json({
        status:0,
        message:'Descripción por Id.',
        data:descripcion
    });
}

const descripcionDelete = async(req, res) => {
    const idDescription = req.params.id;
        
    const descripcion = await Descripciones.update( {active:false}, { where: { idDescription} }  );

    res.json({
        status:0,
        message:'Descripción eliminada.',
        data:descripcion
    });
}

const cbxGetUnidadesMedida = async(req, res = response) => {

    const {
        search = ''
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call cbxGetUnidadesMedida( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxArticulosParaOC = async(req, res = response) => {

    const { idOrdenDeCompra, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxArticulosParaOC( ${ idOrdenDeCompra }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const getProductoByID = async (req, res) => {
    const { idProducto } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProductoByID( ${idProducto} )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxProductos = async(req, res = response) => {

    const {
        search = ''
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call cbxProductos( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const getInsumosByProductosPaginado = async (req, res) => {
    const { idProducto } = req.body;

    try {
        const result = await dbConnection.query(`CALL getInsumosByProductosPaginado( ${ idProducto } )`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const agregarInsumoAlProducto = async (req, res) => {
    const { idProducto, idInsumo, idUserLogON } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL agregarInsumoAlProducto( '${ oGetDateNow }', ${ idProducto }, ${ idInsumo }, ${ idUserLogON } )`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteInsumoDelProducto = async (req, res) => {
    const { keyx } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteInsumoDelProducto( ${ keyx } )`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {
    unidadesMedidaGet,
    unidadMedidaById,
    unidadMedidaDelete,
    unidadesMedidaGuardar,    
    familiasGet,
    familiaById,
    familiaDelete,
    familiasGuardar,
    productoGuardar,     
    productosGetAll, 
    productosGetById,
    productosDelete,
    productoIDSugerido,
    obtenerDescripciones,
    descripcionGuardar,
    descripcionById,
    descripcionDelete,
    cbxGetUnidadesMedida,
    getCatTipoProductoAll,
    cbxArticulosParaOC,
    getProductoByID,

    cbxProductos,
    getInsumosByProductosPaginado,
    agregarInsumoAlProducto,
    deleteInsumoDelProducto
};


