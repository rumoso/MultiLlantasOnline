const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
  getInsumosListWithPage
  , getInsumoByID
  , insertUpdateInsumo
  , deleteInsumo
  , cbxGetInsumos
  , cbxGetInsumosByOrdenCompra
  , cbxGetInsumosByProducto
} = require('../controllers/insumosController');

const router = require('express').Router();

router.post('/getInsumosListWithPage', getInsumosListWithPage);

router.post('/getInsumoByID', [
  check('idInsumo', 'Id obligatorio').not().isEmpty(),
  check('idInsumo', 'Id debe ser numérico').isNumeric(),
  validarCampos
], getInsumoByID);

router.post('/insertUpdateInsumo', [
  check('name', 'Nombre obligatorio').not().isEmpty(),

  validarCampos
], insertUpdateInsumo);

router.post('/deleteInsumo', [
  check('idInsumo', 'Id obligatorio').not().isEmpty(),
  check('idInsumo', 'Id debe ser numérico').isNumeric(),
  validarCampos
], deleteInsumo);

router.post('/cbxGetInsumos', cbxGetInsumos);

router.post('/cbxGetInsumosByOrdenCompra', [
  check('idOrdenDeCompra', 'Id obligatorio').not().isEmpty(),
  check('idOrdenDeCompra', 'Id debe ser numérico').isNumeric(),
  validarCampos
], cbxGetInsumosByOrdenCompra);

router.post('/cbxGetInsumosByProducto', [
  check('idProducto', 'Id obligatorio').not().isEmpty(),
  check('idProducto', 'Id debe ser numérico').isNumeric(),
  validarCampos
], cbxGetInsumosByProducto);

module.exports = router;