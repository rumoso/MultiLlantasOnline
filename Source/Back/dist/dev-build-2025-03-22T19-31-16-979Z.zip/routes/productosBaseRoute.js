const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
  getProductosBaseListWithPage
  , getProductoBaseByID
  , insertUpdateProductoBase
  , deleteProductoBase
  , cbxGetProductosBase
  , agregarMateriaPrimaALaFomulaDeProductoBase
  , getFormulaByProdBasePaginado
  , deleteMateriaPrimaDeLaFormula
  , calcularProduccionProdBase

  , getProdProdBasePaginado
  , cbxProductosBaseForPB
  , agregarProdBaseDetalle
  , getProdProdBaseByID
  , getProdProdBaseDetalle
  , completarYProducirPB
  , deletePPBDetail
} = require('../controllers/productosBaseController');

const router = require('express').Router();

router.post('/getProductosBaseListWithPage', getProductosBaseListWithPage);

router.post('/getProductoBaseByID', [
  check('idProductoBase', 'Id obligatorio').not().isEmpty(),
  check('idProductoBase', 'Id debe ser numérico').isNumeric(),
  validarCampos
], getProductoBaseByID);

router.post('/insertUpdateProductoBase', [
  check('name', 'Nombre obligatorio').not().isEmpty(),

  validarCampos
], insertUpdateProductoBase);

router.post('/deleteProductoBase', [
  check('idProductoBase', 'Id obligatorio').not().isEmpty(),
  check('idProductoBase', 'Id debe ser numérico').isNumeric(),
  validarCampos
], deleteProductoBase);

router.post('/cbxGetProductosBase', cbxGetProductosBase);

router.post('/agregarMateriaPrimaALaFomulaDeProductoBase', [

  check('idProductoBase', 'El Producto Base es obligatorio').not().isEmpty(),
  check('idProductoBase', 'El Producto Base debe ser numérico').isNumeric(),
  check('idProductoBase', 'El Producto debe ser mayor a 0').isFloat({ min: 0.01 }),

  check('idMateriaPrima', 'La Materia Prima es obligatoria').not().isEmpty(),
  check('idMateriaPrima', 'La Materia Prima debe ser numérica').isNumeric(),
  check('idMateriaPrima', 'La Materia Prima debe ser mayor a 0').isFloat({ min: 0.01 }),

  check('cantidad', 'La Cantidad es obligatoria').not().isEmpty(),
  check('cantidad', 'La Cantidad debe ser numérica').isNumeric(),
  check('cantidad', 'La Cantidad debe ser mayor a 0').isFloat({ min: 0.01 }),

  validarCampos
], agregarMateriaPrimaALaFomulaDeProductoBase);

router.post('/getFormulaByProdBasePaginado', [

  check('idProductoBase', 'El Producto Base es obligatorio').not().isEmpty(),
  check('idProductoBase', 'El Producto Base debe ser numérico').isNumeric(),
  check('idProductoBase', 'El Producto debe ser mayor a 0').isFloat({ min: 0.01 }),

  validarCampos
], getFormulaByProdBasePaginado);

router.post('/deleteMateriaPrimaDeLaFormula', [
  check('idFormula', 'Id obligatorio').not().isEmpty(),
  check('idFormula', 'Id debe ser numérico').isNumeric(),
  validarCampos
], deleteMateriaPrimaDeLaFormula);

router.post('/calcularProduccionProdBase', [

  check('idProductoBase', 'El Producto Base es obligatorio').not().isEmpty(),
  check('idProductoBase', 'El Producto Base debe ser numérico').isNumeric(),
  check('idProductoBase', 'El Producto debe ser mayor a 0').isFloat({ min: 0.01 }),

  check('cantAProducir', 'La Cantidad es obligatoria').not().isEmpty(),
  check('cantAProducir', 'La Cantidad debe ser numérica').isNumeric(),
  check('cantAProducir', 'La Cantidad debe ser mayor a 0').isFloat({ min: 0.01 }),

  validarCampos
], calcularProduccionProdBase);

router.post('/getProdProdBasePaginado', getProdProdBasePaginado);

router.post('/cbxProductosBaseForPB', [

  check('idProdProdBaseH', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseH', 'ID debe ser numérico').isNumeric(),

  validarCampos
], cbxProductosBaseForPB);

router.post('/agregarProdBaseDetalle', [

  check('idProductoBase', 'El Producto Base es obligatorio').not().isEmpty(),
  check('idProductoBase', 'El Producto Base debe ser numérico').isNumeric(),
  check('idProductoBase', 'El Producto debe ser mayor a 0').isFloat({ min: 0.01 }),

  check('cantAProducir', 'La Cantidad es obligatoria').not().isEmpty(),
  check('cantAProducir', 'La Cantidad debe ser numérica').isNumeric(),
  check('cantAProducir', 'La Cantidad debe ser mayor a 0').isFloat({ min: 0.01 }),

  validarCampos
], agregarProdBaseDetalle);

router.post('/getProdProdBaseByID', [

  check('idProdProdBaseH', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseH', 'ID debe ser numérico').isNumeric(),

  validarCampos
], getProdProdBaseByID);

router.post('/getProdProdBaseDetalle', [

  check('idProdProdBaseH', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseH', 'ID debe ser numérico').isNumeric(),
  check('idProdProdBaseH', 'ID obligatorio').isFloat({ min: 0.01 }),

  validarCampos
], getProdProdBaseDetalle);

router.post('/completarYProducirPB', [

  check('idProdProdBaseH', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseH', 'ID debe ser numérico').isNumeric(),
  check('idProdProdBaseH', 'ID obligatorio').isFloat({ min: 0.01 }),

  validarCampos
], completarYProducirPB);

router.post('/deletePPBDetail', [

  check('idProdProdBaseH', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseH', 'ID debe ser numérico').isNumeric(),
  check('idProdProdBaseH', 'ID obligatorio').isFloat({ min: 0.01 }),

  check('idProdProdBaseDetalle', 'ID obligatorio').not().isEmpty(),
  check('idProdProdBaseDetalle', 'ID debe ser numérico').isNumeric(),
  check('idProdProdBaseDetalle', 'ID obligatorio').isFloat({ min: 0.01 }),

  validarCampos
], deletePPBDetail);

module.exports = router;