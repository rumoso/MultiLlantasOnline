const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
  getVendedoresListWithPage
  , getVendedorByID
  , insertUpdateVendedor
  , deleteVendedor
   } = require('../controllers/vendedoresController');

   
const router = Router();

router.post('/getVendedoresListWithPage', getVendedoresListWithPage);

router.post('/getVendedorByID', [
  check('idVendedor','Id obligatorio').not().isEmpty(),
  check('idVendedor','Id debe ser numérico').isNumeric(),
  validarCampos
], getVendedorByID);

router.post('/insertUpdateVendedor', [
  check('nombre','Nombre obligatorio').not().isEmpty(),

  validarCampos
], insertUpdateVendedor);

router.post('/deleteVendedor', [
  check('idVendedor','Id de sucursal obligatorio').not().isEmpty(),
  check('idVendedor','Id de sucursal debe ser numérico').isNumeric(),

  validarCampos
], deleteVendedor);

module.exports = router;