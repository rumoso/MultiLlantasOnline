const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
    cbxGetProveedores, 
    proveedoresPaginated, 
    proveedorById, 
    guardarProveedor, 
    eliminarProveedor
} = require('../controllers/proveedoresController');

   
const router = Router();

router.post('/cbxGetProveedores', cbxGetProveedores);
router.post('/getPaginado', proveedoresPaginated);
router.post('/guardar', guardarProveedor);
router.get('/:id', proveedorById);
router.delete('/eliminar/:idProveedor', eliminarProveedor);

module.exports = router;