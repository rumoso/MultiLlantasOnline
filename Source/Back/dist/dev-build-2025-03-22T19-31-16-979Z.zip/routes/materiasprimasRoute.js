const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
  getMateriasPrimasListWithPage
  , getMateriaPrimaByID
  , insertUpdateMateriaPrima
  , deleteMateriaPrima
  , cbxGetMateriasPrimas
  , cbxGetMateriasPrimasByFormulaProdBase
} = require('../controllers/materiasprimasController');

const router = require('express').Router();

router.post('/getMateriasPrimasListWithPage', getMateriasPrimasListWithPage);

router.post('/getMateriaPrimaByID', [
  check('idMateriaPrima', 'Id obligatorio').not().isEmpty(),
  check('idMateriaPrima', 'Id debe ser numérico').isNumeric(),
  validarCampos
], getMateriaPrimaByID);

router.post('/insertUpdateMateriaPrima', [
  check('name', 'Nombre obligatorio').not().isEmpty(),

  check('valorMedida', 'El Valor Medida es obligatorio').not().isEmpty(),
  check('valorMedida', 'El Valor Medida debe ser numérico').isNumeric(),

  check('idUnidadMedida', 'La Unidad de medida es obligatoria').not().isEmpty(),
  check('idUnidadMedida', 'La Unidad de medida debe ser numérico').isNumeric(),

  validarCampos
], insertUpdateMateriaPrima);

router.post('/deleteMateriaPrima', [
  check('idMateriaPrima', 'Id obligatorio').not().isEmpty(),
  check('idMateriaPrima', 'Id debe ser numérico').isNumeric(),
  validarCampos
], deleteMateriaPrima);

router.post('/cbxGetMateriasPrimas', cbxGetMateriasPrimas);

router.post('/cbxGetMateriasPrimasByFormulaProdBase', [
  check('idProductoBase', 'Id obligatorio').not().isEmpty(),
  check('idProductoBase', 'Id debe ser numérico').isNumeric(),
  validarCampos
], cbxGetMateriasPrimasByFormulaProdBase);

module.exports = router;