const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos');

const { getLastCartUser, createUpdateCart, updateQuantityProductCart, deleteProductCart } =  require('../controllers/ventasController');
const router = Router();
router.get('/cart/user/:idUser/:idSucursal', getLastCartUser);
router.post('/cart', createUpdateCart);
router.post('/cart/update/quantity', updateQuantityProductCart);
router.delete('/cart/:id', deleteProductCart);



module.exports = router;