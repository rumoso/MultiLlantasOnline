
const { DataTypes, TINYINT } = require('sequelize');
const { dbConnection } = require('../../database/config');
const UnidadMedida = require('./unidadmedida');
const Descripciones = require('./descripciones');
const CatTipoProducto = require('./cattipoproducto');

const Productos = dbConnection.define('productos', {
        idProducto:{
            type:DataTypes.NUMBER,
            unique:true,
            primaryKey: true,
            autoIncrement:true
        },
        createDate:{
            type:DataTypes.DATE
        },
        sku:{
            type: DataTypes.STRING
        },
        idDescription: {
            type: DataTypes.STRING,            
            references: 'cat_descripciones',
            referencesKey: 'idDescription'
        },
        valorMedida:{
            type:DataTypes.INTEGER
        },
        idUnidadMedida:{
            type:DataTypes.INTEGER,
            references: 'cat_unidad_medida',
            referencesKey: 'idUnidadMedida'
        },
        idCatTipoProducto:{
            type:DataTypes.INTEGER,
            references: 'cat_tipo_producto',
            referencesKey: 'idCatTipoProducto'
        },
        idProductoRelacion:{
            type:DataTypes.INTEGER,
            references: 'productos',
            referencesKey: 'idProducto'
        },   
        cantidad:{
            type: DataTypes.VIRTUAL,
            get() {
                return this.getDataValue('cantidad') || 0;
            },
            set(value) {
                this.setDataValue('cantidad', value);
            }
        },    
        costo:{
            type:DataTypes.FLOAT(10,2)
        },
        precio:{
            type:DataTypes.FLOAT(10,2)
        },
        precioConEnvase:{
            type:DataTypes.FLOAT(10,2)
        },
        precioMayorista:{
            type:DataTypes.FLOAT(10,2)
        },
        precioMayoristaConEnvase:{
            type:DataTypes.FLOAT(10,2)
        },
        active:{
            type:DataTypes.TINYINT
        },
    },{    
    createdAt: false,
    updatedAt: false
    });

    Productos.belongsTo(UnidadMedida,{
        foreignKey:'idUnidadMedida',
        as:'unidadmedida',
    });
    Productos.belongsTo(Descripciones,{
        foreignKey:'idDescription',        
        as:'descripciones'
    });

    Productos.belongsTo(Productos,{
        foreignKey:'idProductoRelacion',
        as:'productobase'
    });

    Productos.belongsTo(CatTipoProducto,{
        foreignKey:'idCatTipoProducto',
        as:'tipoproducto'
    });
module.exports= Productos;











