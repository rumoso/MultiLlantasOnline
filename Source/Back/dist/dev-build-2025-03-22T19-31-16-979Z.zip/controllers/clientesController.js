const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getClientesListWithPage = async (req, res = response) => {
    const { search = '', limiter = 10, start = 0 } = req.body;

    try {
        var OSQL = await dbConnection.query(`call getClientesListWithPage('${search}', ${start}, ${limiter})`);

        const iRows = OSQL.length > 0 ? OSQL[0].iRows : 0;

        res.json({
            status: 0,
            message: "Ejecutado correctamente.",
            data: {
                count: iRows,
                rows: OSQL
            }
        });

    } catch (error) {
        
        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
};


const getClienteByID = async (req, res = response) => {
    const { idCliente } = req.body;

    try {
        var OSQL = await dbConnection.query(`call getClienteByID(${idCliente})`);

        res.json({
            status: 0,
            message: "Ejecutado correctamente.",
            data: OSQL[0] || null
        });

    } catch (error) {

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
};

const insertUpdateCliente = async (req, res = response) => {
    const {
        idCliente,
        nombre,
        calle,
        numExt,
        numInt,
        entreCalles="",
        codigocolonia,
        rfc,
        telefono,
        email,
        lat = 0,
        long = 0,
        active
    } = req.body;

    const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

    try {
        var OSQL = await dbConnection.query(`call insertUpdateCliente(
            '${oGetDateNow}',
            ${idCliente},
            '${nombre}',
            '${calle}',
            '${numExt}',
            '${numInt}',
            '${entreCalles}',
            '${codigocolonia}',
            '${rfc}',
            '${telefono}',
            '${email}',
            '${lat}',
            '${long}',
            ${active}
        )`);

        res.json({
            status: OSQL[0].out_id > 0 ? 0 : 1,
            message: OSQL[0].message,
            insertID: OSQL[0].out_id
        });

    } catch (error) {

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
};


const deleteCliente = async (req, res = response) => {
    const { idCliente } = req.body;

    try {
        var OSQL = await dbConnection.query(`call deleteCliente(${idCliente})`);

        res.json({
            status: 0,
            message: "Eliminado correctamente.",
            data: OSQL
        });
    } catch (error) {
        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });
    }
};

module.exports = {
    getClientesListWithPage
    , getClienteByID
    , insertUpdateCliente
    , deleteCliente
  }