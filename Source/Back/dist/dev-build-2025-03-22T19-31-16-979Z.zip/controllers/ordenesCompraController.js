const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getOrdenesCompraListWithPage = async (req, res) => {
    const { search = '', limiter = 10, start = 0, idUserLogON } = req.body;

    try {
        const result = await dbConnection.query(`CALL getOrdenesCompraListWithPage('${search}', ${start}, ${limiter}, ${idUserLogON})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getOrdenCompraByID = async (req, res) => {
    const { idOrdenDeCompra } = req.body;

    try {
        const result = await dbConnection.query(`CALL getOrdenCompraByID(${idOrdenDeCompra})`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const insertUpdateOrdenCompra = async (req, res) => {
    const {
        idOrdenDeCompra
        , idProveedor
        , active
        , numeroFactura = ''
        , fechaPedido = ''
        , fechaRecepcion = ''
        , idUserLogON
    } = req.body;

    try {

        if(!idProveedor > 0){
            return res.json({
                status: 1,
                message: 'Debes seleccionar proveedor'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateOrdenCompra( 
            '${ oGetDateNow }'
            , ${ idOrdenDeCompra }
            , ${ idProveedor }
            , '${ numeroFactura }'
            , '${ fechaPedido ? fechaPedido.substring(0, 10) : '0' }'
            , '${ fechaRecepcion ? fechaRecepcion.substring(0, 10) : '0' }'
            , ${ active }
            , ${ idUserLogON }
            )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteOrdenCompra = async (req, res) => {
    const { idOrdenDeCompra } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteOrdenCompra(${idOrdenDeCompra})`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const agregarOrdenCompraDetalle = async (req, res) => {
    const { idOrdenDeCompra, idProducto, cantidad, costo } = req.body;

    try {

        if(!(idOrdenDeCompra > 0 && idProducto > 0 && cantidad > 0 && costo > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL agregarOrdenCompraDetalle( ${ idOrdenDeCompra }, ${ idProducto }, '${ cantidad }', '${ costo }')`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getOrdenCompraDetailListWithPage = async (req, res) => {
    const { idOrdenDeCompra = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getOrdenCompraDetailList( ${ idOrdenDeCompra } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: result.length,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteOrdenCompraDetalle = async (req, res) => {
    const { idOrdenDeCompra, idOrdenDeCompraDetalle } = req.body;

    try {

        if(!idOrdenDeCompraDetalle > 0){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL deleteOrdenCompraDetalle( ${ idOrdenDeCompra }, ${ idOrdenDeCompraDetalle } )`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const completarOrdenCompra = async (req, res) => {
    const { idOrdenDeCompra, idUserLogON } = req.body;

    try {

        if(!(idOrdenDeCompra > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL completarOrdenCompra( '${ oGetDateNow }', ${ idOrdenDeCompra }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const agregarInsumoOrdenCompra = async (req, res) => {
    const { idOrdenDeCompra, idInsumo, cantidadInsumo, costoInsumo } = req.body;

    try {

        if(!(idOrdenDeCompra > 0 && idInsumo > 0 && cantidadInsumo > 0 && costoInsumo > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL agregarInsumoOrdenCompra( 
            ${ idOrdenDeCompra }
            , ${ idInsumo }
            , '${ cantidadInsumo }'
            , '${ costoInsumo }'
            )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteInsumoOrdenCompra = async (req, res) => {
    const { idOrdenDeCompra, idOrdenDeCompraInsumo } = req.body;

    try {

        if(!idOrdenDeCompraInsumo > 0){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL deleteInsumoOrdenCompra( ${ idOrdenDeCompra }, ${ idOrdenDeCompraInsumo } )`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });

    } catch (error) {
        return res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {
    getOrdenesCompraListWithPage
    , getOrdenCompraByID
    , insertUpdateOrdenCompra
    , deleteOrdenCompra
    , agregarOrdenCompraDetalle
    , getOrdenCompraDetailListWithPage
    , deleteOrdenCompraDetalle
    , completarOrdenCompra
    , agregarInsumoOrdenCompra
    , deleteInsumoOrdenCompra
};
