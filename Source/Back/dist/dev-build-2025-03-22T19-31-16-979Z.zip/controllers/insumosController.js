const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getInsumosListWithPage = async (req, res) => {
    const { search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getInsumosListWithPage('${search}', ${start}, ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getInsumoByID = async (req, res) => {
    const { idInsumo } = req.body;

    try {
        const result = await dbConnection.query(`CALL getInsumoByID( ${idInsumo} )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const insertUpdateInsumo = async (req, res) => {
    const { idInsumo, name, active } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateInsumo( '${ oGetDateNow }', ${ idInsumo }, '${ name }', ${ active })`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteInsumo = async (req, res) => {
    const { idInsumo } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteInsumo( ${ idInsumo } )`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxGetInsumos = async(req, res = response) => {

    const { search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetMateriasPrimas( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxGetInsumosByOrdenCompra = async(req, res = response) => {

    const { idOrdenDeCompra, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetInsumosByOrdenCompra( ${ idOrdenDeCompra }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxGetInsumosByProducto = async(req, res = response) => {

    const { idProducto, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetInsumosByProducto( ${ idProducto }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

module.exports = {
    getInsumosListWithPage
    , getInsumoByID
    , insertUpdateInsumo
    , deleteInsumo
    , cbxGetInsumos
    , cbxGetInsumosByOrdenCompra

    , cbxGetInsumosByProducto
};
