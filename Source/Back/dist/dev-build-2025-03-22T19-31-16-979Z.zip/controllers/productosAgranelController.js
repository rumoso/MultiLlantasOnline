const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getProductosAgranelListWithPage = async (req, res) => {
    const { search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProductosAgranelListWithPage('${search}', ${start}, ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProductoAgranelByID = async (req, res) => {
    const { idProductoAgranel } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProductoAgranelByID(${idProductoAgranel})`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const insertUpdateProductoAgranel = async (req, res) => {
    const { idProductoAgranel, name, active } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateProductoAgranel( '${ oGetDateNow }', ${idProductoAgranel}, '${name}', ${active})`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteProductoAgranel = async (req, res) => {
    const { idProductoAgranel } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteProductoAgranel(${idProductoAgranel})`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxGetProductosAgranel = async(req, res = response) => {

    const { search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetProductosAgranel( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const consultarInvParaGenerarProdAgranel = async (req, res) => {
    const { idProductoAgranel } = req.body;

    try {

        const result = await dbConnection.query(`CALL consultarInvParaGenerarProdAgranel( ${ idProductoAgranel } )`);
        console.log(result);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result || null
        });

    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const producirProdAgranel = async (req, res) => {
    const { idProductoAgranel, cantAProducir, oDetailList } = req.body;

    console.log( req.body )

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const jsonString = JSON.stringify(oDetailList, null, 2);
        console.log( 'jsonString', jsonString )

        let costoTotal = oDetailList.reduce((acumulador, item) => acumulador + item.costoTotal, 0);

        //console.log( 'costoTotal', costoTotal )
        
        const oSQL = await dbConnection.query(`CALL producirProdAgranel(
            '${ oGetDateNow }'
            , ${ idProductoAgranel }
            , '${ cantAProducir }'
            , '${ costoTotal }'
            , '${ jsonString }'
            )`);
        console.log('oSQL', oSQL);

        return res.json({
            status: oSQL[0].out_id > 0 ? 0 : 1,
            message: oSQL[0].message,
            insertID: oSQL[0].out_id
        });

    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};



const getProdProdAgranelPaginado = async (req, res) => {
    const { startDate = '', endDate = '', search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdAgranelPaginado(
            '${ startDate.substring(0, 10) }'
            , '${ endDate.substring(0, 10) }'
            , '${search}'
            , ${start}
            , ${limiter}
            )`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxProductosAgranelForPA = async(req, res = response) => {

    const { search = '', idProdProdAgranelH } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxProductosAgranelForPA( '${ search }', ${ idProdProdAgranelH } )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const agregarProdAgranelDetalle = async (req, res) => {
    var { idProdProdAgranelH = 0, idProductoAgranel, cantAProducir, oInvParaGenerar, idUserLogON } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        let costoTotal = 0;
        oInvParaGenerar.forEach(item => {
            costoTotal += parseFloat(item.cantidadDisponible) * parseFloat(item.costo);
        });

        if(idProdProdAgranelH == 0)
        {
            var oInsertUpdate = await dbConnection.query(`CALL insertUpdateProdProdAgranel(
                '${ oGetDateNow }'
                , ${ idProdProdAgranelH }
                , 1
                , ${ idUserLogON })`);

            if(oInsertUpdate.length == 0){
                return res.json({
                    status: 2,
                    message: 'No se pudo generar ID para la producción'
                });
            }
            else{
                idProdProdAgranelH = oInsertUpdate[0].out_id;
                
            }
        }

        var oAgregarPPADetalle = await dbConnection.query(`CALL agregarProdProdAgranelDetalle(
            '${ oGetDateNow }'
            , ${ idProdProdAgranelH }
            , ${ idProductoAgranel }
            , ${ cantAProducir }
            , ${ costoTotal / cantAProducir }
            , ${ costoTotal }
            , ${ 1 })`);

        console.log('oAgregarPPADetalle', oAgregarPPADetalle)

        if(oAgregarPPADetalle.length == 0){
            return res.json({
                status: 2,
                message: 'No se pudo agregar el producto a la lista'
            });
        }
        else{
            var idProdProdDetalle = oAgregarPPADetalle[0].out_id;

            console.log( 'idProdProdDetalle', idProdProdDetalle )

            const jsonString = JSON.stringify(oInvParaGenerar, null, 2);
            console.log( 'jsonString', jsonString )
            
            const oSQL = await dbConnection.query(`CALL insertProdProdAgranelStock(
                ${ idProdProdDetalle }
                , '${ jsonString }'
                )`);

            console.log('oSQL', oSQL);

        
        }

        return res.json({
            status: idProdProdAgranelH > 0 ? 0 : 1,
            message: idProdProdAgranelH > 0 ? 'Agregado correctamente.' : 'No pudo agregar',
            insertID: idProdProdAgranelH,
        });

    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdAgranelByID = async (req, res) => {
    const { idProdProdAgranelH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdAgranelByID( ${ idProdProdAgranelH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdAgranelDetalle = async (req, res) => {
    const { idProdProdAgranelH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdAgranelDetalle( ${ idProdProdAgranelH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const completarYProducirPA = async (req, res) => {
    const { idProdProdAgranelH, idUserLogON } = req.body;

    try {

        if(!(idProdProdAgranelH > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL producirProdAgranel( '${ oGetDateNow }', ${ idProdProdAgranelH }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deletePPADetail = async (req, res) => {
    const { idProdProdAgranelH, idProdProdAgranelDetalle, idUserLogON } = req.body;

    try {

        if(!(idProdProdAgranelH > 0 && idProdProdAgranelDetalle > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const result = await dbConnection.query(`CALL deletePPBDetail( ${ idProdProdAgranelH }, ${ idProdProdAgranelDetalle }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].iRows > 0 ? 0 : 1,
            message: "Eliminado correctamente"
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {
    getProductosAgranelListWithPage
    , getProductoAgranelByID
    , insertUpdateProductoAgranel
    , deleteProductoAgranel
    , cbxGetProductosAgranel
    , consultarInvParaGenerarProdAgranel
    , producirProdAgranel

    , getProdProdAgranelPaginado
    , cbxProductosAgranelForPA
    , agregarProdAgranelDetalle
    , getProdProdAgranelByID
    , getProdProdAgranelDetalle
    , completarYProducirPA
    , deletePPADetail
};
