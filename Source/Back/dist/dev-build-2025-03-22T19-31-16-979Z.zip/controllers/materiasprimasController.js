const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getMateriasPrimasListWithPage = async (req, res) => {
    const { search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getMateriasPrimasListWithPage('${search}', ${start}, ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getMateriaPrimaByID = async (req, res) => {
    const { idMateriaPrima } = req.body;

    try {
        const result = await dbConnection.query(`CALL getMateriaPrimaByID(${idMateriaPrima})`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const insertUpdateMateriaPrima = async (req, res) => {
    const { idMateriaPrima, name, valorMedida, idUnidadMedida, active } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateMateriaPrima( '${ oGetDateNow }', ${idMateriaPrima}, '${name}', ${valorMedida}, ${idUnidadMedida}, ${active})`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteMateriaPrima = async (req, res) => {
    const { idMateriaPrima } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteMateriaPrima(${idMateriaPrima})`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxGetMateriasPrimas = async(req, res = response) => {

    const { search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetMateriasPrimas( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxGetMateriasPrimasByOrdenCompra = async(req, res = response) => {

    const { idOrdenDeCompra, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetMateriasPrimasByOrdenCompra( ${ idOrdenDeCompra }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxGetMateriasPrimasByFormulaProdBase = async(req, res = response) => {

    const { idProductoBase, search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetMateriasPrimasByFormulaProdBase( ${ idProductoBase }, '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

module.exports = {
    getMateriasPrimasListWithPage
    , getMateriaPrimaByID
    , insertUpdateMateriaPrima
    , deleteMateriaPrima
    , cbxGetMateriasPrimas
    , cbxGetMateriasPrimasByOrdenCompra
    , cbxGetMateriasPrimasByFormulaProdBase
};
