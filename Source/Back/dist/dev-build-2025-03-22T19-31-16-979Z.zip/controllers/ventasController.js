const { response } = require('express');
const { Op } = require('sequelize');
const { dbConnection } = require('../database/config');
const {Cart} = require('../models/ventas/cart');
const CartDetail = require('../models/ventas/cartdetail');


const getLastCartUser = async(req, res = response) => {
    try {
        const {idUser, idSucursal} = req.params;
        
        const cart = await Cart.findOne({ 
            where: {
                idUser, 
                idSucursal
            },
            include: [{
                model: CartDetail,
                as: 'productos',
                required: false
            }],
            order: [
                ['idcart', 'DESC'],
                [{ model: CartDetail, as: 'productos' }, 'idcartDetail', 'DESC']
            ]
        });

        res.json({
            status: 0,
            message: 'Obtener carrito usuario actual',
            data: cart
        });
    } catch (error) {
        console.error('Error en getLastCartUser:', error);
        res.status(500).json({
            status: 1,
            message: 'Error al obtener el carrito',
            error: error.message
        });
    }
}

const createUpdateCart = async (req, res = response) => {
    const { idcart = 0, idUser, idCliente, idSucursal, productos } = req.body;
    let newCart = null;
    const t = await dbConnection.transaction();
    try {

        if( idcart === 0){
            newCart = await Cart.create({ 
                createDate: new Date(), 
                idUser, 
                idCliente, 
                idSucursal }, { transaction: t });
        }      

        const cartId = newCart ? newCart.idcart : idcart;

        // Procesar cada producto
        for(const producto of productos) {
            // Buscar si el producto ya existe en el carrito
            const existingProduct = await CartDetail.findOne({
                where: {
                    idcart: cartId,
                    idProducto: producto.idProducto
                }
            });

            if(existingProduct) {
                // Si existe, actualizar sumando la cantidad
                await CartDetail.update(
                    {
                        cantidad: parseFloat(existingProduct.cantidad) + producto.cantidad
                    },
                    {
                        where: {
                            idcart: cartId,
                            idProducto: producto.idProducto
                        },
                        transaction: t
                    }
                );
            } else {
                // Si no existe, crear nuevo registro
                await CartDetail.create({
                    idcart: cartId,
                    sku: producto.sku,
                    idProducto: producto.idProducto,
                    descripcion: producto.descripcion,
                    cantidad: producto.cantidad,
                    precio: producto.precio
                }, { transaction: t });
            }
        }

        await t.commit();

        res.json({
            status: 0,
            message: 'Carrito creado exitosamente',
            data: newCart
        });
    } catch (error) {
        await t.rollback();
        res.status(500).json({
            status: 1,
            message: 'Error al crear el carrito',
            error: error.message
        });
    }


}

const deleteProductCart = async (req, res = response) => {
    const idcartDetail = req.params.id;
    const cartDetail = await CartDetail.destroy({where:{idcartDetail}});
    
    res.json({
        status:0,
        message:'Carrito, producto eliminado con éxito.',
        data:cartDetail
    });
}

const updateQuantityProductCart = async (req, res = response) => {
    const { idcartDetail, cantidad } = req.body;
    const cartDetail = await CartDetail.update({ cantidad }, {where:{idcartDetail}});
    
    res.json({
        status:0,
        message:'Cantidad actualizada con éxito.',
        data:cartDetail
    });
}


module.exports = { getLastCartUser, createUpdateCart, updateQuantityProductCart, deleteProductCart }