const { response } = require('express');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const { dbConnection } = require('../database/config');

const getProductosBaseListWithPage = async (req, res) => {
    const { search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProductosBaseListWithPage('${search}', ${start}, ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProductoBaseByID = async (req, res) => {
    const { idProductoBase } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProductoBaseByID(${idProductoBase})`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const insertUpdateProductoBase = async (req, res) => {
    const { idProductoBase, name, active } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL insertUpdateProductoBase( '${ oGetDateNow }', ${idProductoBase}, '${name}', ${active})`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteProductoBase = async (req, res) => {
    const { idProductoBase } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteProductoBase(${idProductoBase})`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxGetProductosBase = async(req, res = response) => {

    const { search = '' } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxGetProductosBase( '${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const agregarMateriaPrimaALaFomulaDeProductoBase = async (req, res) => {
    const { idProductoBase, idMateriaPrima, cantidad, idUserLogON } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL agregarMateriaPrimaALaFomulaDeProductoBase( '${ oGetDateNow }', ${ idProductoBase }, ${ idMateriaPrima }, '${ cantidad }', ${ idUserLogON } )`);

        res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getFormulaByProdBasePaginado = async (req, res) => {
    const { idProductoBase, search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getFormulaByProdBasePaginado( ${ idProductoBase }, '${search}', ${start}, ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deleteMateriaPrimaDeLaFormula = async (req, res) => {
    const { idFormula } = req.body;

    try {
        const result = await dbConnection.query(`CALL deleteMateriaPrimaDeLaFormula( ${ idFormula } )`);

        res.json({
            status: 0,
            message: 'Eliminado correctamente.',
            data: result
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const calcularProduccionProdBase = async (req, res) => {
    const { bProducir, idProductoBase, cantAProducir } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const inventario = await dbConnection.query(`CALL consultarInvParaFormulaDeProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
        console.log(inventario);

        if(inventario.length == 0){
            return res.json({
                status: 2,
                message: 'No hay inventario para generar esta fórmula'
            });
        }


        const requerimiento = await dbConnection.query(`CALL consultarFormulaNecesariaProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
        console.log(requerimiento);

        if(requerimiento.length > 0 && inventario.length > 0){
        
            let resultado = [];

            requerimiento.forEach((req) => {
                let { idMateriaPrima, cantNecesaria, materiaPrimaName } = req;
                let stockDisponible = inventario
                    .filter((item) => item.idMateriaPrima === idMateriaPrima)
                    .sort((a, b) => a.idStock - b.idStock); // FIFO: Más viejo primero
    
                //console.log('cantNecesaria', cantNecesaria);
                //console.log('stockDisponible', stockDisponible);
    
                let cantidadRestante = cantNecesaria;
    
                for (let stock of stockDisponible) {
    
                    if (cantidadRestante <= 0) break;
    
                    let cantidadATomar = Math.min(stock.cantidadDisp, cantidadRestante);
                    //console.log('cantidadATomar', cantidadATomar);
                    resultado.push({
                        bOK: cantidadATomar > 0,
                        idStock: stock.idStock,
                        createDate: stock.createDate,
                        idMateriaPrima,
                        materiaPrimaName,
                        cantidadDisp: stock.cantidadDisp,
                        cantidadConsumida: Number((cantidadATomar).toFixed(2)), // Redondeo a 2 decimales,
                        costoUnitario: stock.costo,
                        costoTotal: Number((stock.costo * cantidadATomar).toFixed(2)),
                        idOrdenDeCompra: ( stock.idOrdenDeCompra > 0 ? 'OC#' + stock.idOrdenDeCompra : '' )
                    });
    
                    cantidadRestante -= cantidadATomar;
                }
    
                if (cantidadRestante > 0) {
                    resultado.push({
                        bOK: false,
                        idStock: null, 
                        createDate: null,
                        idMateriaPrima,
                        materiaPrimaName,
                        cantidadDisp: 0,
                        cantidadConsumida: Number(cantidadRestante.toFixed(2)),
                        costoUnitario: 0,
                        costoTotal: 0,
                        idOrdenDeCompra: ''
                    });
                }
            });
    
            console.log(resultado)
    
            let costoTotal = 0;
            let bOKGeneral = true;
    
            resultado.forEach(item => {
                costoTotal += parseFloat(item.costoTotal);
                if (item.bOK == false) {
                    bOKGeneral = false;
                }
            });

            if(bOKGeneral && bProducir){

                const jsonString = JSON.stringify(resultado, null, 2);
                //console.log( 'jsonString', jsonString )
                
                const oSQL = await dbConnection.query(`CALL producirProdBase(
                    '${ oGetDateNow }'
                    , ${ idProductoBase }
                    , '${ cantAProducir }'
                    , '${ costoTotal }'
                    , '${ jsonString }'
                    )`);
                console.log('oSQL', oSQL);

                return res.json({
                    status: oSQL[0].out_id > 0 ? 0 : 1,
                    message: oSQL[0].message,
                    insertID: oSQL[0].out_id
                });

            }

            return res.json({
                status: 0,
                message: 'Ejecutado correctamente.',
                data: {
                    bOKGeneral: bOKGeneral,
                    costoTotal: costoTotal,
                    cantProducida: cantAProducir,
                    rows: resultado
                }
            });

        }
        
    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdBasePaginado = async (req, res) => {
    const { startDate = '', endDate = '', search = '', limiter = 10, start = 0 } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdBasePaginado(
            '${ startDate.substring(0, 10) }'
            , '${ endDate.substring(0, 10) }'
            ,'${search}'
            , ${start}
            , ${limiter})`);
        const iRows = result.length > 0 ? result[0].iRows: 0;

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                count: iRows,
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const cbxProductosBaseForPB = async(req, res = response) => {

    const { search = '', idProdProdBaseH } = req.body;

    try{

        var OSQL = await dbConnection.query(`call cbxProductosBaseForPB( '${ search }', ${ idProdProdBaseH } )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const agregarProdBaseDetalle = async (req, res) => {
    var { idProdProdBaseH = 0, idProductoBase, cantAProducir, idUserLogON } = req.body;

    try {

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const inventario = await dbConnection.query(`CALL consultarInvParaFormulaDeProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
        console.log(inventario);

        if(inventario.length == 0){
            return res.json({
                status: 2,
                message: 'No hay inventario para generar esta fórmula'
            });
        }


        const requerimiento = await dbConnection.query(`CALL consultarFormulaNecesariaProdBase( ${ idProductoBase }, '${cantAProducir}' )`);
        console.log(requerimiento);

        if(requerimiento.length > 0 && inventario.length > 0){
        
            let resultado = [];

            requerimiento.forEach((req) => {
                let { idMateriaPrima, cantNecesaria, materiaPrimaName } = req;
                let stockDisponible = inventario
                    .filter((item) => item.idMateriaPrima === idMateriaPrima)
                    .sort((a, b) => a.idStock - b.idStock); // FIFO: Más viejo primero
    
                //console.log('cantNecesaria', cantNecesaria);
                //console.log('stockDisponible', stockDisponible);
    
                let cantidadRestante = cantNecesaria;
    
                for (let stock of stockDisponible) {
    
                    if (cantidadRestante <= 0) break;
    
                    let cantidadATomar = Math.min(stock.cantidadDisp, cantidadRestante);
                    //console.log('cantidadATomar', cantidadATomar);
                    resultado.push({
                        bOK: cantidadATomar > 0,
                        idStock: stock.idStock,
                        createDate: stock.createDate,
                        idMateriaPrima,
                        materiaPrimaName,
                        cantidadDisp: stock.cantidadDisp,
                        cantidadConsumida: Number((cantidadATomar).toFixed(2)), // Redondeo a 2 decimales,
                        costoUnitario: stock.costo,
                        costoTotal: Number((stock.costo * cantidadATomar).toFixed(2)),
                        idOrdenDeCompra: ( stock.idOrdenDeCompra > 0 ? 'OC#' + stock.idOrdenDeCompra : '' )
                    });
    
                    cantidadRestante -= cantidadATomar;
                }
    
                if (cantidadRestante > 0) {
                    resultado.push({
                        bOK: false,
                        idStock: null, 
                        createDate: null,
                        idMateriaPrima,
                        materiaPrimaName,
                        cantidadDisp: 0,
                        cantidadConsumida: Number(cantidadRestante.toFixed(2)),
                        costoUnitario: 0,
                        costoTotal: 0,
                        idOrdenDeCompra: ''
                    });
                }
            });
    
            console.log(resultado)
    
            let costoTotal = 0;
            let bOKGeneral = true;
    
            resultado.forEach(item => {
                costoTotal += parseFloat(item.costoTotal);
                if (item.bOK == false) {
                    bOKGeneral = false;
                }
            });

            if(idProdProdBaseH == 0 && bOKGeneral)
            {
                var oInsertUpdate = await dbConnection.query(`CALL insertUpdateProdProdBase(
                    '${ oGetDateNow }'
                    , ${ idProdProdBaseH }
                    , 1
                    , ${ idUserLogON })`);

                if(oInsertUpdate.length == 0){
                    return res.json({
                        status: 2,
                        message: 'No se pudo generar ID para la producción'
                    });
                }
                else{
                    idProdProdBaseH = oInsertUpdate[0].out_id;
                    
                }
            }

            if(bOKGeneral){

                var oAgregarPPBDetalle = await dbConnection.query(`CALL agregarProdProdBaseDetalle(
                    '${ oGetDateNow }'
                    , ${ idProdProdBaseH }
                    , ${ idProductoBase }
                    , ${ cantAProducir }
                    , ${ costoTotal / cantAProducir }
                    , ${ costoTotal }
                    , ${ bOKGeneral ? 1 : 0 })`);
    
                console.log('oAgregarPPBDetalle', oAgregarPPBDetalle)

                if(oAgregarPPBDetalle.length == 0){
                    return res.json({
                        status: 2,
                        message: 'No se pudo agregar el producto base a la lista'
                    });
                }
                else{
                    var idProdProdBaseDetalle = oAgregarPPBDetalle[0].out_id;

                    console.log( 'idProdProdBaseDetalle', idProdProdBaseDetalle )

                    const jsonString = JSON.stringify(resultado, null, 2);
                    //console.log( 'jsonString', jsonString )
                    
                    const oSQL = await dbConnection.query(`CALL insertProdProdBaseStock(
                        ${ idProdProdBaseDetalle }
                        , '${ jsonString }'
                        )`);

                    console.log('oSQL', oSQL);

                
                }

            }

            return res.json({
                status: bOKGeneral ? 0 : 1,
                message: bOKGeneral ? 'Ejecutado correctamente.' : 'No hay inventario',
                insertID: idProdProdBaseH,
                data: {
                    bOKGeneral: bOKGeneral,
                    costoTotal: costoTotal,
                    cantProducida: cantAProducir,
                    rows: resultado
                }
            });

        }
        
    } catch (error) {
        res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdBaseByID = async (req, res) => {
    const { idProdProdBaseH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdBaseByID( ${ idProdProdBaseH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: result[0] || null
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const getProdProdBaseDetalle = async (req, res) => {
    const { idProdProdBaseH } = req.body;

    try {
        const result = await dbConnection.query(`CALL getProdProdBaseDetalle( ${ idProdProdBaseH } )`);

        res.json({
            status: 0,
            message: 'Ejecutado correctamente.',
            data: {
                rows: result
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const completarYProducirPB = async (req, res) => {
    const { idProdProdBaseH, idUserLogON } = req.body;

    try {

        if(!(idProdProdBaseH > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const oGetDateNow = moment().format('YYYY-MM-DD HH:mm:ss');

        const result = await dbConnection.query(`CALL producirProdBase2( '${ oGetDateNow }', ${ idProdProdBaseH }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].out_id > 0 ? 0 : 1,
            message: result[0].message,
            insertID: result[0].out_id
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

const deletePPBDetail = async (req, res) => {
    const { idProdProdBaseH, idProdProdBaseDetalle, idUserLogON } = req.body;

    try {

        if(!(idProdProdBaseH > 0 && idProdProdBaseDetalle > 0)){
            return res.json({
                status: 1,
                message: 'Parametros incorrectos'
            });
        }

        const result = await dbConnection.query(`CALL deletePPBDetail( ${ idProdProdBaseH }, ${ idProdProdBaseDetalle }, ${ idUserLogON } )`);

        return res.json({
            status: result[0].iRows > 0 ? 0 : 1,
            message: "Eliminado correctamente"
        });

    } catch (error) {
        return res.json({
            status: 2,
            message: 'Sucedió un error inesperado',
            data: error.message
        });
    }
};

module.exports = {
    getProductosBaseListWithPage
    , getProductoBaseByID
    , insertUpdateProductoBase
    , deleteProductoBase
    , cbxGetProductosBase
    , agregarMateriaPrimaALaFomulaDeProductoBase
    , getFormulaByProdBasePaginado
    , deleteMateriaPrimaDeLaFormula
    , calcularProduccionProdBase
    , getProdProdBasePaginado
    , cbxProductosBaseForPB
    , agregarProdBaseDetalle
    , getProdProdBaseByID
    , getProdProdBaseDetalle
    , completarYProducirPB
    , deletePPBDetail
};
